### 欢迎来到[班级网站](http://summon00163.github.io)！
感谢您来到班级网站，<br>
下面几个文件可以编辑


>[编辑成员](https://github.com/summon00163/summon00163.github.io/blob/main/json/member.json)<br>
>[新闻目录编辑](https://github.com/summon00163/summon00163.github.io/blob/main/json/news.json)<br>
>[快乐学习编辑](https://github.com/summon00163/summon00163.github.io/blob/main/json/study.json)<br>
>[编辑聊天内容](https://github.com/summon00163/summon00163.github.io/blob/main/json/chat.json)<br>
>[编辑“听我说”内容](https://github.com/summon00163/summon00163.github.io/blob/main/json/say.json)<br>
>[编辑荣誉内容](https://github.com/summon00163/summon00163.github.io/blob/main/json/honor.json)<br>

---

## 作文上传
先在[这里](https://github.com/summon00163/summon00163.github.io/blob/main/article/demo.html)点击`Download raw file`，完成编辑之后在[这里](https://github.com/summon00163/summon00163.github.io/tree/main/article)上传，最后还要在[这里](https://github.com/summon00163/summon00163.github.io/blob/main/json/study.json)的`article`中更新哦！

## 学习成果（知识分享）上传
先在[这里](https://github.com/summon00163/summon00163.github.io/blob/main/learn/demo.html)点击`Download raw file`，完成编辑之后在[这里](https://github.com/summon00163/summon00163.github.io/tree/main/learn)上传，最后还要在[这里](https://github.com/summon00163/summon00163.github.io/blob/main/json/study.json)的`learn`中更新哦！

## 上传图片
先在[这里](https://github.com/summon00163/summon00163.github.io/blob/main/story/subgallery/sub.js)看已有图片的数量，<br>
然后图片分类别写上序号（例如`1-14.jpg`），然后在[这里](https://github.com/summon00163/summon00163.github.io/tree/main/story/subgallery/images)上传图片，最后还要在[这里](https://github.com/summon00163/summon00163.github.io/blob/main/story/subgallery/sub.js)写上图片数量哦！
>

---

我们正在征集网站图标,在[这里](https://github.com/summon00163/summon00163.github.io/tree/main/icons)上传方案！

---

[源码下载](http://summon00163.github.io/source-code.zip)
