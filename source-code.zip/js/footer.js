// JavaScript Document
document.writeln("<footer>");
document.writeln("	<span>联系我们：</span><br/>");
document.writeln("	<span><a href=\'tel:\'>0769-**** ****</a></span><br/>");
document.writeln("	<span><a href=\'mailto:\'>******@***.com</a></span><br/>");
document.writeln("	<span></span><br/>");
document.writeln("	<span><a href=\'http://summon00163.github.io/class20/FAQ.html\'>常见问题</a></span><br/>");
document.writeln("	<span><a href=\'https://summon00163.github.io/class20/source-code.zip\'>源码下载</a></span><br/>");
document.writeln("	<span><a href=\'https://github.com/summon00163/class20\'>源码查看</a></span><br/>");
document.writeln("</footer>");